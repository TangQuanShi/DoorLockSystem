#include "sys.h"
#include "beep.h"
#include "delay.h"
/*********************************************************************************
			  ___   _     _____  _____  _   _  _____  _____  _   __
			 / _ \ | |   |_   _||  ___|| \ | ||_   _||  ___|| | / /
			/ /_\ \| |     | |  | |__  |  \| |  | |  | |__  | |/ /
			|  _  || |     | |  |  __| | . ` |  | |  |  __| |    \
			| | | || |_____| |_ | |___ | |\  |  | |  | |___ | |\  \
			\_| |_/\_____/\___/ \____/ \_| \_/  \_/  \____/ \_| \_/

 *	******************************************************************************
 *	������ֻ��ѧϰʹ�ã�δ���������ɣ��������������κ���;
 *	ALIENTEK Pandora STM32L IOT������
 *	��������������
 *	����ԭ��@ALIENTEK
 *	������̳:www.openedv.com
 *	��������:2018/10/27
 *	�汾��V1.0
 *	��Ȩ���У�����ؾ���
 *	Copyright(C) �������������ӿƼ����޹�˾ 2014-2024
 *	All rights reserved
 *	******************************************************************************
 *	��ʼ�汾
 *	******************************************************************************/

/**
 * @brief	������ IO��ʼ������
 *
 * @param   void
 *
 * @return  void
 */
void BEEP_Init(void)
{
    GPIO_InitTypeDef GPIO_InitStruct;

    __HAL_RCC_GPIOB_CLK_ENABLE();	//ʹ��GPIOBʱ��

    //PB2
    GPIO_InitStruct.Pin = GPIO_PIN_2;
    GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
    GPIO_InitStruct.Pull = GPIO_PULLDOWN;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
    HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

    HAL_GPIO_WritePin(GPIOB, GPIO_PIN_2, GPIO_PIN_RESET);
}


void Sound(u16 frq)
{
    u32 time;
    if(frq != 1000)
    {
        time = 500000/((u32)frq);
        BEEP(1);
        delay_us(time);
        BEEP(0);
        delay_us(time);
    }else
        delay_us(1000);
}

void play_music(void)
{
	//             ?7  1   2   3   4   5   6   7  ?1 ?2  ?3 ?4 ?5 ???
	uc16 tone[] = {247,262,294,330,349,392,440,494,523,587,659,698,784,1000};//?????
 
	//???

	u8 music[]={13,1,2,3};//?????
	u8 time[] ={1,1,1,1};
 
	u32 yanshi;
	u16 i,e;
	yanshi = 2;//10;  4;  2
	for(i=0;i<sizeof(music)/sizeof(music[0]);i++){
		for(e=0;e<((u16)time[i])*tone[music[i]]/yanshi;e++){
			Sound((u32)tone[music[i]]);
		}	
	}
}
void play_ermusic(void)
{
	//             ?7  1   2   3   4   5   6   7  ?1 ?2  ?3 ?4 ?5 ???
	uc16 tone[] = {247,262,294,330,349,392,440,494,523,587,659,698,784,1000};//?????
 
	//???

	u8 music[]={3,2,1,13};//?????
	u8 time[] ={1,1,1,1};
 
	u32 yanshi;
	u16 i,e;
	yanshi = 2;//10;  4;  2
	for(i=0;i<sizeof(music)/sizeof(music[0]);i++){
		for(e=0;e<((u16)time[i])*tone[music[i]]/yanshi;e++){
			Sound((u32)tone[music[i]]);
		}	
	}
}









