#include "sys.h"
#include "usart.h"
#include "usmart.h"
#include "delay.h"
#include "led.h"
#include "key.h"
#include "lcd.h"
#include "malloc.h"
#include "w25qxx.h"
#include "sd_card.h"
#include "ff.h"
#include "exfuns.h"
#include "fontupd.h"
#include "text.h"
#include "spi2.h"
#include "rc522.h"
#include "exti.h"
#include "pwm.h"
#include "aht10.h"
#include "beep.h"
#include "rtc.h"
uint8_t UID[4],Temp[4];

uint8_t UI0[4]={0xFF,0xFF,0xFF,0xFF};		 	//?0ID?
uint8_t UI1[4]={0xFF,0xFF,0xFF,0xFF};	 		//?1ID?
uint8_t UI2[4]={0xFF,0xFF,0xFF,0xFF};			//?2ID?
uint8_t UI3[4]={0xFF,0xFF,0xFF,0xFF};			//?3ID?


UART_HandleTypeDef huart1; 
/*********************************************************************************
			  ___   _     _____  _____  _   _  _____  _____  _   __
			 / _ \ | |   |_   _||  ___|| \ | ||_   _||  ___|| | / /
			/ /_\ \| |     | |  | |__  |  \| |  | |  | |__  | |/ /
			|  _  || |     | |  |  __| | . ` |  | |  |  __| |    \
			| | | || |_____| |_ | |___ | |\  |  | |  | |___ | |\  \
			\_| |_/\_____/\___/ \____/ \_| \_/  \_/  \____/ \_| \_/

 *	******************************************************************************
 *	ALIENTEK Pandora STM32L IOT������	ʵ��28
 *	������ʾʵ��		HAL��汾
 *	����֧�֣�www.openedv.com
 *	�Ա����̣�http://eboard.taobao.com
 *	��ע΢�Ź���ƽ̨΢�źţ�"����ԭ��"����ѻ�ȡSTM32���ϡ�
 *	�������������ӿƼ����޹�˾
 *	���ߣ�����ԭ�� @ALIENTEK
 *	******************************************************************************/


/***********************************************************************

					SPI FLASH(W25Q128)��Դ����

	���	 ƫ�Ƶ�ַ			��С		�洢����
	 1		0x00000000		0x00200000		Ԥ����RT Threadʹ��(2M)
	 2		0x00200000		0x00603000		Ԥ���������ֿ�ʹ��(6156K)
	 3		0x00803000		0x000FD000		Ԥ�����û�ʹ��(1012K)
	 4		0x00900000		0x00700000		Ԥ����FATFSʹ��(7M)

************************************************************************/
unsigned char BlockNum = 0;		
unsigned char KeyModel = 0x61;	
unsigned char Key[6]={0xff,0xff,0xff,0xff,0xff,0xff};
u8 CardWData0[16]={'b','5',0x02,0,0,0,0,0,0,0,0,0,0,0,0,0};  
u8 CardWData1[16]={'b','4',0x02,0,0,0,0,0,0,0,0,0,0,0,0,0};  
u8 CardWData2[16]={'b','3',0x02,0,0,0,0,0,0,0,0,0,0,0,0,0};  
u8 CardWData3[16]={'b','2',0x02,0,0,0,0,0,0,0,0,0,0,0,0,0};  
u8 StartAddrH = 0,StartAddrL = 1;	 
u8 CardRData[16]={0}; 

void weather(  float temperature, float humidity)
{
		RTC_TimeTypeDef RTC_TimeStruct;
		RTC_DateTypeDef RTC_DateStruct;
		char tbuf[40];
		HAL_RTC_GetTime(&RTC_Handler, &RTC_TimeStruct, RTC_FORMAT_BIN);
		sprintf((char*)tbuf, "Time:%02d:%02d", RTC_TimeStruct.Hours, RTC_TimeStruct.Minutes);
		LCD_ShowString(30, 1, 210, 16, 16, tbuf);
		HAL_RTC_GetDate(&RTC_Handler, &RTC_DateStruct, RTC_FORMAT_BIN);
		sprintf((char*)tbuf, "Date:20%02d-%02d-%02d", RTC_DateStruct.Year, RTC_DateStruct.Month, RTC_DateStruct.Date);
		LCD_ShowString(30, 21, 210, 16, 16, tbuf);
	
	
		LCD_ShowString(30, 190, 200, 16, 16, "Temp:   . C");
		LCD_ShowString(30, 210, 200, 16, 16, "Humi:   . %RH");
		LCD_ShowNum(30 + 48, 190, temperature, 2, 16);					//��ʾ�¶�����
		LCD_ShowNum(30 + 72, 190, (u32)(temperature * 10) % 10, 1, 16);	//��ʾ�¶�С��
		LCD_ShowNum(30 + 48, 210, humidity, 2, 16);						//��ʾʪ������
		LCD_ShowNum(30 + 72, 210, (u32)(humidity * 10) % 10, 1, 16);	//��ʾʪ��С��		
		if(humidity>80)	
		{
				LCD_ShowString(30, 170, 200, 16, 16, "Rainny   ");
		}
		else 
		{
			if(temperature>26)
			{
				LCD_ShowString(30, 170, 200, 16, 16, "Sunny    ");
			}
			else
			{
				LCD_ShowString(30, 170, 200, 16, 16, "Cloudy  	");
			}
		}

}

static void MX_USART1_UART_Init(void)
{
  huart1.Instance = USART1;
  huart1.Init.BaudRate = 115200;
  huart1.Init.WordLength = UART_WORDLENGTH_8B;
  huart1.Init.StopBits = UART_STOPBITS_1;
  huart1.Init.Parity = UART_PARITY_NONE;
  huart1.Init.Mode = UART_MODE_TX_RX;
  huart1.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart1.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart1) != HAL_OK)
  {
		while(1)
		{
			LCD_Clear(WHITE);	
			Show_Str(60,100,200,16,(u8 *)"ERROR!",16);
			HAL_Delay(1000);
		}
  }
}



int stop=0;
int wifi=0;
int main(void)
{
		float temperature,  humidity;
    u32 fontcnt;
    u8 i, j;
    u8 fontx[2];                    //gbk��
    u8 key, t;
		u8 SelectedSnr[4] ;
		u8 time = 0;
    u8 speed = 1;				//�ٶȿ���		0:����		1������
    u8 dir = 1;	
		u16 pwmval = 400;

    HAL_Init();
    SystemClock_Config();		//��ʼ��ϵͳʱ��Ϊ80M
    delay_init(80); 			//��ʼ����ʱ����    80Mϵͳʱ��
    uart_init(115200);			//��ʼ�����ڣ�������Ϊ115200
    usmart_dev.init(80);		//��ʼ�����ڵ������
		HAL_UART_MspInit(&huart1);
		MX_USART1_UART_Init();
	
	

		
    RTC_Init();	
		BEEP_Init();
		PWM_Init(1000 - 1, 80 - 1);
    LED_Init();					//��ʼ��LED
    KEY_Init();					//��ʼ������
    LCD_Init();					//��ʼ��LCD
    W25QXX_Init();				//��ʼ��W25Q256
		EXTI_Init();
		AHT10_Init();
		LCD_Clear(WHITE);		   	//����
		POINT_COLOR = RED;			//��������Ϊ��ɫ
		
		
    RFID_Init();
	while(font_init()) 			//����ֿ�
	{	    
		LCD_ShowString(30,85,200,16,16,"Font Error!");
		delay_ms(200);				  
		LCD_Fill(30,85,240,101,WHITE);//�����ʾ	     
		delay_ms(200);				  
	}
	
//	RTC_Set_Time(12,  32, 55, RTC_HOURFORMAT12_PM);
//	RTC_Set_Date( 23, 6,  1,  7);


    while(1)
    {
		Show_Str(60,100,200,16,(u8 *)"Selecting....",16);	
		temperature = AHT10_Read_Temperature();
		humidity = AHT10_Read_Humidity();
		weather(temperature, humidity);	
			
			
			if(wifi>=1)
			{
				char buffer[]="identify\r\n";
				HAL_UART_Transmit(&huart1, (uint8_t *)buffer, strlen(buffer), HAL_MAX_DELAY);
				HAL_Delay(1000);
				LCD_Clear(WHITE);	
				Show_Str(60,100,200,16,(u8 *)"Send Success!",16);
				HAL_Delay(1000);
				LED_G(1);LED_R(0);LED_B(0);
				uint8_t rxData;
				
				LED_G(0);LED_R(1);LED_B(1);
				LCD_Clear(WHITE);	
				Show_Str(60,100,200,16,(u8 *)"Wait!",16);
				HAL_UART_Receive(&huart1, &rxData, 1, 10000);
				if(rxData == 1)
				{
					LCD_Clear(WHITE);
					Show_Str(60,100,200,16,(u8 *)"Success",16);
					HAL_Delay(2000);
					TIM_SetTIM2Compare1(pwmval);
					TIM_SetTIM2Compare2(0);
					play_music();
				}
				else
				{
					LCD_Clear(WHITE);
					Show_Str(60,100,200,16,(u8 *)"Fail",16);
					HAL_Delay(2000);
					play_ermusic();
				}
				LED_G(1);LED_R(1);LED_B(1);
				delay_ms(2000);	
				TIM_SetTIM2Compare2(0);
				TIM_SetTIM2Compare1(0);

			wifi=0;
			}
				
		
		if(stop>=1 )
		{		

			if(stop==1)
			{
					LCD_Clear(WHITE);	
					weather(temperature, humidity);
					Show_Str(40,100,200,16,(u8 *)"The Writing User is ",16);	
					LCD_ShowNum(80, 140, stop, 5, 16);
					LED_R(1);LED_B(1);
					SreachCard(SelectedSnr);
					PcdAuthState(KeyModel, BlockNum, Key,SelectedSnr);  		// У����������
					WriteCard(SelectedSnr,StartAddrH,StartAddrL,CardWData0);  	//ִ��д������
					if(MI_OK == ReadCard(SelectedSnr,StartAddrH,StartAddrL,CardRData))	//������0����0�ڵ�����
				{
					LCD_Clear(WHITE);	
					weather(temperature, humidity);
					Show_Str(60,100,200,30,(u8 *)"Write Success!",16);
					LED_G(1);LED_R(1);LED_B(1);
					stop=0;	
				}


			}			
			if(stop==2)
			{
					LCD_Clear(WHITE);	
					weather(temperature, humidity);				
					Show_Str(40,100,200,16,(u8 *)"The Writing User is ",16);	
					LCD_ShowNum(80, 140, stop, 5, 16);
					LED_R(1);LED_B(1);			
					SreachCard(SelectedSnr);
					PcdAuthState(KeyModel, BlockNum, Key,SelectedSnr);  		// У����������
					WriteCard(SelectedSnr,StartAddrH,StartAddrL,CardWData1);  	//ִ��д������
					if(MI_OK == ReadCard(SelectedSnr,StartAddrH,StartAddrL,CardRData))	//������0����0�ڵ�����
				{
					LCD_Clear(WHITE);	
									weather(temperature, humidity);
					Show_Str(60,100,200,16,(u8 *)"Write Success!",16);
					LED_G(1);LED_R(1);LED_B(1);
					stop=0;	
				}
			}
			if(stop==3)
			{
					LCD_Clear(WHITE);		
					weather(temperature, humidity);
					Show_Str(40,100,200,16,(u8 *)"The Writing User is ",16);	
					LCD_ShowNum(80, 140, stop, 5, 16);
					LED_R(1);LED_B(1);
					SreachCard(SelectedSnr);
					PcdAuthState(KeyModel, BlockNum, Key,SelectedSnr);  		// У����������
					WriteCard(SelectedSnr,StartAddrH,StartAddrL,CardWData2);  	//ִ��д������
					if(MI_OK == ReadCard(SelectedSnr,StartAddrH,StartAddrL,CardRData))	//������0����0�ڵ�����
				{
					LCD_Clear(WHITE);	
									weather(temperature, humidity);
					Show_Str(60,100,200,16,(u8 *)"Write Success!",16);
					LED_G(1);LED_R(1);LED_B(1);
					stop=0;	
				}

			}
						if(stop==4)
			{
					LCD_Clear(WHITE);		
					weather(temperature, humidity);
					Show_Str(40,100,200,16,(u8 *)"The Writing User is ",16);	
					LCD_ShowNum(80, 140, stop, 5, 16);
					LED_R(1);LED_B(1);
					SreachCard(SelectedSnr);
					PcdAuthState(KeyModel, BlockNum, Key,SelectedSnr);  		// У����������
					WriteCard(SelectedSnr,StartAddrH,StartAddrL,CardWData3);  	//ִ��д������
					if(MI_OK == ReadCard(SelectedSnr,StartAddrH,StartAddrL,CardRData))	//������0����0�ڵ�����
				{
					LCD_Clear(WHITE);	
					weather(temperature, humidity);
					Show_Str(60,100,200,16,(u8 *)"Write Success!",16);
					LED_G(1);LED_R(1);LED_B(1);
					stop=0;	
				}

			}
				if(stop>4)
			{
							LCD_Clear(WHITE);		
							weather(temperature, humidity);
							Show_Str(30,100,200,16,(u8 *)"The User is not Success",16);	
							stop=0;	
			}			
		}
		else 
		{		
			Show_Str(60,100,200,16,(u8 *)"Selecting....",16);	
			weather(temperature, humidity);
			SreachCard(SelectedSnr);
			PcdAuthState(KeyModel, BlockNum, Key,SelectedSnr);  		// У����������

			if(MI_OK == ReadCard(SelectedSnr,StartAddrH,StartAddrL,CardRData))	//������0����0�ڵ�����
				{
				if(CardRData[1]==CardWData0[1])
					{
					LCD_Clear(WHITE);
					weather(temperature, humidity);						
					Show_Str(60,100,200,16,(u8 *)"Welcome USER1!",16);	
					TIM_SetTIM2Compare1(pwmval);
					TIM_SetTIM2Compare2(0);
					play_music();
					}
				if(CardRData[1]==CardWData1[1])
					{
					LCD_Clear(WHITE);		
					weather(temperature, humidity);						
					Show_Str(60,100,200,16,(u8 *)"Welcome USER2!",16);	
					TIM_SetTIM2Compare1(pwmval);
					TIM_SetTIM2Compare2(0);
					play_music();
					}
				if(CardRData[1]==CardWData2[1])
					{
					LCD_Clear(WHITE);		 
					weather(temperature, humidity);
					Show_Str(60,100,200,16,(u8 *)"Welcome USER3!",16);	
					TIM_SetTIM2Compare1(pwmval);
					TIM_SetTIM2Compare2(0);
					}
				if(CardRData[1]==CardWData3[1])
					{
					LCD_Clear(WHITE);		 
					weather(temperature, humidity);
					Show_Str(60,100,200,16,(u8 *)"Welcome USER4!",16);	

					}
			}
		}			
		
					delay_ms(2000);	
					TIM_SetTIM2Compare2(0);
					TIM_SetTIM2Compare1(0);
        		LCD_Clear(WHITE);		   	//����
						weather(temperature, humidity);
   }
}


